JAVA="java"
JAR="Lavalink.jar"

echo "[INFO] Starting Lavalink server..."
${JAVA} -jar -Xms128M -Xmx2048M ${JAR}